                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2626736
Ursa King Cab Body by Superclodbuster is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Body set for Ursa Bear Monster truck.
https://www.thingiverse.com/thing:2299884

Based on the Tamiya King Cab.(1988 Nissan/Datsun Pickup; Big Bear was based on a early 80s Datsun/Nissan pickup)

Designed similar to original Ursa bear body. Will require a longer front body mount which is included. the rear body mount uses the same mount as the original Ursa bear body.
you will need 2 more 3mmX10 Screws for this body as the rollbar uses 4 bolts.

.2 Layer Height.

About 50 grams heavier then the original Ursa Bear body, this new body is wider, longer, and taller then original.

Parts list:
King URSA Center Body Piece   (Cab center of body)
King URSA Front Body Mount    (new longer front body mount for King Ursa, use original rear body mount)
King URSA Front body piece ( front/nose of body) insert a 100% layer at 115
King URSA Optional Grill Insert Piece 1 (to help with painting the Black outs for the hood ducts)
King URSA Optional Grill Insert Piece 2 (to help with painting the Black outs for the hood ducts)
King URSA Optional Grill Insert Piece 3 (to help with painting the Black outs for the hood ducts)
King URSA Rear Body Piece (rear body bed of truck, insert a 100% fill layer at 160)
King URSA Rear Window (glue to Cab, makes the rear window of the cab)
King URSA Roll Bar (body roll bar)

The Optional Grill inserts go into the hood. Glue them in place, they are meant to be tight but you may need to sand them to fit. 

2% infill 1 perimeter for body. Rollbar 25% infill. Designed to print as orientated. 

https://www.youtube.com/watch?v=Z2g8C345iLM

# Print Settings

Printer Brand: Prusa
Printer: i3 MK2S
Rafts: No
Supports: No
Resolution: .2
Infill: 2%

Notes: 
designed to be printed without supports. i like to put a 5mm Brim around the body parts to make sure they stay flat on the print bed.